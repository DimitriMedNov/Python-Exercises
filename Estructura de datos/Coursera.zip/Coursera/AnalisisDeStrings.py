# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 14:59:11 2021

@author: MedNo
"""
s1 = "Prueba"


s1.count('a')
s1.startswith('a')
s1.endswith('a')
s1.find('ue')
s1.index('a')
s1.rfind('ue')
s1.rindex('a')
s1.isdecimal()
s1.isdigit()
s1.islower()
s1.isupper()
s1.istitle()
s1.isspace()
s1.isalpha()
s1.isalnum()
