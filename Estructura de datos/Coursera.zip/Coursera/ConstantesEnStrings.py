# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 16:32:33 2021

@author: MedNo
"""

import string

string.ascii_letters
string.ascii_lowercase
string.ascii_uppercase
string.digits
string.hexdigits
string.octdigits
string.punctuation
string.printable
string.whitespace
