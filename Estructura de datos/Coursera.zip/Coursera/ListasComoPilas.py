# -*- coding: utf-8 -*-
"""
Created on Tue Oct 26 11:34:22 2021

@author: MedNo
"""
stack = [1, 2, 3]

#Ingreso de elementos
stack.append(4)
stack.append(5)

#Sacar los elementos
stack.pop()
stack.pop()
stack.pop()