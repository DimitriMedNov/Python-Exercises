# -*- coding: utf-8 -*-
"""
Created on Sat Nov  6 23:42:15 2021

@author: MedNo
"""

# Empaquetado
a = 30
b = "T"
c = "A"
tupla = a,b,c

# Desempaquetado
X,y,z = tupla
# errores por distintos tamaños a desempaquetar.
x,y = tupla
w,x,y,z = tupla