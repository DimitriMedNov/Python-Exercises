# -*- coding: utf-8 -*-
"""
Created on Sat Oct  9 14:41:11 2021

@author: MedNo
"""
s1="Prueba"
s2="prueba"
s3="  prueba"
s4="Hola Mundo"

s5="abracadabra"

s6="    python es genial!    "

s7= "1, 2, 3, 4"



s2.capitalize()
s1.lower()
s2.upper()
s3.strip()
s4.split(" ")
s1.swapcase()
s2.title()
s3.rstrip()
s3.lstrip()
s1.rjust(10)
s1.ljust(10)
s2.replace("r", "h")
s1.center(10)
s1.zfill(10)#Dentro del () debe ir un numero

s5.replace("a", "e")

s7.split(',')
